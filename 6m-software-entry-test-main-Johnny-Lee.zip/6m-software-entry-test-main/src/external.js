//Do not change anything in this file. Only q4.js is the one that needs to be changed.
const print = () => {
    return "Hello World";
}

export default print;

