
/*
    Task 1:
    - Link the file `external.js` to this file.
    - To test if the linking works, open q5-output.html using VScode's Live Server extension. It should print "Hello World!"
    - You can refer to this link: https://www.w3schools.com/js/js_modules.asp to check how imports and modules are done.
*/

// Task 1: Add code here
import { print } from './external.js';
// Do not change the code below
document.querySelector("#test").innerHTML = print();
